"use strict";

let randomNumber = Math.floor(Math.random() * 30) + 1;

let score = 10;
document.querySelector(".score").textContent = score;
let highscore = 0;
document.querySelector(".highscore").textContent = highscore;

const displayMessage = function (message) {
  document.querySelector(".message").textContent = message;
};

const clicker = document.querySelector(".click");
clicker.addEventListener("click", function () {
  //  displayMessage(`no number`);

  const inputValue = Number(document.querySelector(".input").value);

  if (!inputValue) {
    displayMessage(`Not a Number!⛔`);
  } else if (inputValue === randomNumber) {
    displayMessage(`Congratulations! 😃 `);
    document.querySelector("body").style.backgroundColor = "green";
    document.querySelector(".guess").textContent = randomNumber;

    if (score > highscore) {
      highscore = score;
      document.querySelector(".highscore").textContent = highscore;
    }
  } else if (inputValue !== randomNumber) {
    if (score >= 1 && score !== 0) {
      score--;
      document.querySelector(".score").textContent = score;
      displayMessage(inputValue > randomNumber ? " 📈Too High" : "📉Too low!!");
    } else {
      displayMessage(`😭 Game over! Try Again?`);
      document.querySelector("body").style.backgroundColor = "skyblue";
    }
  }
});
const again = document.querySelector(".again");
again.addEventListener("click", function () {
  randomNumber = Math.floor(Math.random() * 30) + 1;
  document.querySelector("body").style.backgroundColor =
    "rgba(90, 40, 90, 0.267)";
  document.querySelector("input").value = "";
  document.querySelector(".guess").textContent = "Start guessing?...";

  score = 10;
  document.querySelector(".score").textContent = score;
  highscore = 0;
  document.querySelector(".highscore").textContent = highscore;
});
